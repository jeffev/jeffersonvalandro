// Cliente MCP de linha de comando: sobe o servidor pelo stdio, lista as
// tools e chama cada uma. Uso: npm run build && node scripts/cliente.mjs
import { Client } from "@modelcontextprotocol/client";
import {
  StdioClientTransport,
  getDefaultEnvironment,
} from "@modelcontextprotocol/client/stdio";

const raiz = process.argv[2] ?? "exemplo";

const transporte = new StdioClientTransport({
  command: process.execPath, // o mesmo node que roda este script
  args: ["dist/index.js", raiz],
  // o cliente NÃO repassa todo o seu ambiente: passe o que o servidor usa
  env: { ...getDefaultEnvironment(), PRIMEIRO_MCP_SCRIPTS: "test,lint" },
  stderr: "inherit",
});

const cliente = new Client({ name: "cliente-do-livro", version: "1.0.0" });
await cliente.connect(transporte);
console.log("protocolo:", cliente.getNegotiatedProtocolVersion());

const { tools } = await cliente.listTools();
console.log("tools:", tools.map((t) => t.name).join(", "));

const chamadas = [
  ["buscar_texto", { texto: "cupom" }],
  ["listar_todos", { marcadores: ["TODO", "FIXME", "HACK"] }],
  ["rodar_script", { script: "test" }],
  ["buscar_texto", { texto: "API_TOKEN" }],
  ["buscar_texto", { texto: "senha", pasta: "../.." }],
  ["rodar_script", { script: "deploy" }],
];
for (const [name, args] of chamadas) {
  const r = await cliente.callTool({ name, arguments: args });
  const texto = r.content.map((c) => c.text ?? "").join("\n");
  console.log(`\n> ${name} ${JSON.stringify(args)}`);
  console.log(r.isError ? `[isError] ${texto}` : texto);
}

await cliente.close();
