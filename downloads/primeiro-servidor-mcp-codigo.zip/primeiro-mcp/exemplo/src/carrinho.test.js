import { test } from "node:test";
import assert from "node:assert/strict";
import { frete, total } from "./carrinho.js";

test("soma preço vezes quantidade", () => {
  assert.equal(total([{ preco: 10, quantidade: 3 }]), 30);
});

test("frete grátis a partir de 200", () => {
  assert.equal(frete(250), 0);
  assert.equal(frete(50), 19.9);
});
