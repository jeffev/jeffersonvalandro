// Carrinho de compras da loja de exemplo.

export function total(itens) {
  // TODO: aplicar cupons de desconto
  return itens.reduce((soma, i) => soma + i.preco * i.quantidade, 0);
}

export function frete(valor) {
  // FIXME: frete grátis deveria valer a partir de 199, não 200
  return valor >= 200 ? 0 : 19.9;
}
