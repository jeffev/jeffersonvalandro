# Ideias

- Mostrar o frete antes do checkout.
- HACK: hoje o frete é calculado duas vezes na página do carrinho.
