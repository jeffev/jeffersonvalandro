// Teste de ponta a ponta: sobe `node dist/index.js` de verdade e conversa
// com ele pelo stdio usando o Client oficial do SDK.
import path from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { Client } from "@modelcontextprotocol/client";
import {
  StdioClientTransport, getDefaultEnvironment,
} from "@modelcontextprotocol/client/stdio";
import { projetoTemporario, textoDe } from "./ajuda.js";

const aqui = path.dirname(fileURLToPath(import.meta.url));
const dist = path.resolve(aqui, "..", "dist");

async function abrir(arquivo: string, args: string[], modo?: any) {
  const cliente = new Client({ name: "teste-stdio", version: "1.0.0" },
    modo ? { versionNegotiation: { mode: modo } } : undefined);
  await cliente.connect(new StdioClientTransport({
    command: process.execPath,
    args: [path.join(dist, arquivo), ...args],
    env: { ...getDefaultEnvironment(), PRIMEIRO_MCP_SCRIPTS: "test" },
    stderr: "pipe",
  }));
  return cliente;
}

const projeto = () => projetoTemporario({
  "package.json": JSON.stringify({
    scripts: { test: "node -e \"console.log('ok pelo stdio')\"" } }),
  "src/a.js": "// TODO: escrever o resto\n",
});

describe("primeiro-mcp pelo stdio", () => {
  it.each([
    ["padrão do cliente (era 2025)", undefined, /^2025-/],
    ["fixado em 2026-07-28", { pin: "2026-07-28" }, /^2026-07-28$/],
  ])("%s: lista e chama todas as tools", async (_n, modo, versao) => {
    const cliente = await abrir("index.js", [projeto()], modo);
    try {
      expect(cliente.getNegotiatedProtocolVersion()).toMatch(versao);
      const { tools } = await cliente.listTools();
      expect(tools.map((t) => t.name))
        .toEqual(["buscar_texto", "listar_todos", "rodar_script"]);
      const busca = await cliente.callTool(
        { name: "buscar_texto", arguments: { texto: "resto" } });
      expect(textoDe(busca)).toContain("src/a.js:1:");
      const todos = await cliente.callTool(
        { name: "listar_todos", arguments: {} });
      expect(todos.structuredContent).toMatchObject({ total: 1 });
      const script = await cliente.callTool(
        { name: "rodar_script", arguments: { script: "test" } });
      expect(textoDe(script)).toContain("ok pelo stdio");
    } finally {
      await cliente.close();
    }
  });

  it("o exemplo ola.js responde à tool saudar", async () => {
    const cliente = await abrir("ola.js", []);
    try {
      const r = await cliente.callTool(
        { name: "saudar", arguments: { nome: "Ana" } });
      expect(textoDe(r)).toBe("Olá, Ana! Sou um servidor MCP.");
    } finally {
      await cliente.close();
    }
  });
});
