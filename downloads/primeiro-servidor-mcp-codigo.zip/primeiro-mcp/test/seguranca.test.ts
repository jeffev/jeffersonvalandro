import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  ambienteDoFilho, ehSegredo, estaDentro, limitar, resolverNaRaiz,
} from "../src/seguranca.js";
import { projetoTemporario } from "./ajuda.js";

describe("resolverNaRaiz", () => {
  const raiz = projetoTemporario({ "docs/a.md": "oi" });

  it("aceita caminhos dentro da raiz", () => {
    expect(resolverNaRaiz(raiz, "docs")).toBe(path.join(raiz, "docs"));
    expect(resolverNaRaiz(raiz, ".")).toBe(raiz);
  });

  it.each(["..", "../..", "docs/../../x", path.resolve(os.tmpdir())])(
    "recusa %s",
    (pedido) => {
      expect(() => resolverNaRaiz(raiz, pedido)).toThrow(/fora da raiz/);
    },
  );

  it("recusa link que aponta para fora da raiz", () => {
    const fora = projetoTemporario({ "segredo.txt": "x" });
    // junction funciona no Windows sem privilégio de administrador
    fs.symlinkSync(fora, path.join(raiz, "atalho"), "junction");
    expect(() => resolverNaRaiz(raiz, "atalho")).toThrow(/aponta para fora/);
  });

  it("não confunde pasta irmã com prefixo parecido", () => {
    expect(estaDentro("/projetos/app", "/projetos/app-antigo")).toBe(false);
  });
});

describe("arquivos de segredo", () => {
  it.each([".env", ".env.local", "chave.pem", "id_ed25519", ".npmrc"])(
    "%s é bloqueado",
    (nome) => expect(ehSegredo(nome)).toBe(true),
  );
  it.each([".env.example", "README.md", "environment.ts"])(
    "%s é liberado",
    (nome) => expect(ehSegredo(nome)).toBe(false),
  );
});

describe("ambienteDoFilho", () => {
  it("passa PATH e corta tokens", () => {
    const env = ambienteDoFilho({
      PATH: "/bin", GITHUB_TOKEN: "ghp_x", AWS_SECRET_ACCESS_KEY: "y",
    });
    expect(env).toEqual({ PATH: "/bin" });
  });
});

describe("limitar", () => {
  it("corta e avisa", () => {
    expect(limitar("abcdef", 3)).toBe("abc\n[... 3 caracteres omitidos]");
    expect(limitar("abc", 3)).toBe("abc");
  });
});
