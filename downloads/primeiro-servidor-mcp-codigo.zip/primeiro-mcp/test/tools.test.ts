import { afterAll, beforeAll, describe, expect, it } from "vitest";
import type { Client } from "@modelcontextprotocol/client";
import { conectar, configPara, projetoTemporario, textoDe } from "./ajuda.js";

const PROJETO = {
  "package.json": JSON.stringify({
    type: "module",
    scripts: {
      test: "node -e \"console.log('testes ok')\"",
      falha: "node -e \"process.exit(3)\"",
      lento: "node -e \"setTimeout(() => {}, 20000)\"",
      ambiente:
        "node -e \"console.log(process.env.SEGREDO_DO_TESTE ?? 'nada')\"",
    },
  }),
  "src/app.js": "// TODO: validar entrada\nconst cupom = 'BLACK10';\n",
  "src/util.js": "// FIXME: nome ruim\n// HACK: provisório\n// TODOS os itens\n",
  "notas/reuniao.md": "Cliente pediu cupom de desconto.\n",
  ".env": "CUPOM_SECRETO=nao-pode-aparecer\n",
  "node_modules/lib/index.js": "// TODO: isto é de terceiros\n",
};

describe("tools (cliente em memória)", () => {
  let raiz: string;
  let cliente: Client;
  const chamar = (name: string, args: Record<string, unknown> = {}) =>
    cliente.callTool({ name, arguments: args });

  beforeAll(async () => {
    raiz = projetoTemporario(PROJETO);
    cliente = await conectar(configPara(raiz, {
      scripts: ["test", "falha", "lento", "ambiente"], timeoutMs: 1_000,
    }));
  });
  afterAll(async () => cliente.close());

  it("lista as três tools em ordem fixa, com anotações", async () => {
    const { tools } = await cliente.listTools();
    expect(tools.map((t) => t.name))
      .toEqual(["buscar_texto", "listar_todos", "rodar_script"]);
    const porNome = Object.fromEntries(tools.map((t) => [t.name, t]));
    expect(porNome.buscar_texto.annotations?.readOnlyHint).toBe(true);
    expect(porNome.rodar_script.annotations?.destructiveHint).toBe(true);
    expect(porNome.buscar_texto.inputSchema.required).toEqual(["texto"]);
  });

  describe("buscar_texto", () => {
    it("acha o texto com arquivo e linha", async () => {
      const t = textoDe(await chamar("buscar_texto", { texto: "CUPOM" }));
      expect(t).toContain("notas/reuniao.md:1: Cliente pediu cupom");
      expect(t).toContain("src/app.js:2:");
    });

    it("não lê .env nem node_modules", async () => {
      const t = textoDe(await chamar("buscar_texto", { texto: "SECRETO" }));
      expect(t).toContain("Nenhuma ocorrência");
      const t2 = textoDe(await chamar("buscar_texto", { texto: "terceiros" }));
      expect(t2).toContain("Nenhuma ocorrência");
    });

    it("respeita a subpasta e o limite", async () => {
      const t = textoDe(await chamar("buscar_texto",
        { texto: "cupom", pasta: "notas" }));
      expect(t).not.toContain("src/app.js");
      const um = textoDe(await chamar("buscar_texto",
        { texto: "cupom", maxResultados: 1 }));
      expect(um).toContain("1 ocorrência(s)");
    });

    it("devolve isError para caminho fora da raiz", async () => {
      const r = await chamar("buscar_texto", { texto: "x1", pasta: "../" });
      expect(r.isError).toBe(true);
      expect(textoDe(r)).toContain("fora da raiz");
    });

    it("devolve isError quando a entrada não passa no schema", async () => {
      const r = await chamar("buscar_texto", { texto: "x" });
      expect(r.isError).toBe(true);
      expect(textoDe(r)).toMatch(/texto/);
    });
  });

  describe("listar_todos", () => {
    it("lista TODO e FIXME por padrão, com dados estruturados", async () => {
      const r = await chamar("listar_todos");
      expect(r.structuredContent).toEqual({
        total: 2,
        itens: [
          { arquivo: "src/app.js", linha: 1, marcador: "TODO",
            texto: "TODO: validar entrada" },
          { arquivo: "src/util.js", linha: 1, marcador: "FIXME",
            texto: "FIXME: nome ruim" },
        ],
      });
      expect(textoDe(r)).toContain("src/util.js:1: FIXME: nome ruim");
    });

    it("aceita outros marcadores e ignora TODOS", async () => {
      const r = await chamar("listar_todos", { marcadores: ["HACK"] });
      expect(r.structuredContent).toMatchObject({ total: 1 });
      const todos = await chamar("listar_todos", { marcadores: ["TODO"] });
      expect(textoDe(todos)).not.toContain("TODOS os itens");
    });

    it("recusa marcador fora da lista", async () => {
      const r = await chamar("listar_todos", { marcadores: ["BUG"] });
      expect(r.isError).toBe(true);
    });

    it("devolve isError (sem dados) para pasta fora da raiz", async () => {
      const r = await chamar("listar_todos", { pasta: ".." });
      expect(r.isError).toBe(true);
      expect(r.structuredContent).toBeUndefined();
    });
  });

  describe("rodar_script", () => {
    it("roda um script liberado", async () => {
      const t = textoDe(await chamar("rodar_script", { script: "test" }));
      expect(t).toContain("código de saída 0");
      expect(t).toContain("testes ok");
    });

    it("informa quando o script falha", async () => {
      const t = textoDe(await chamar("rodar_script", { script: "falha" }));
      // o script sai com 3; o node --run devolve 3 ou 1, conforme o sistema
      expect(t).toMatch(/código de saída [13]$/m);
    });

    it("recusa script fora da lista", async () => {
      const r = await chamar("rodar_script", { script: "deploy; rm -rf /" });
      expect(r.isError).toBe(true);
    });

    it("encerra script que passa do tempo", async () => {
      const t = textoDe(await chamar("rodar_script", { script: "lento" }));
      expect(t).toContain("TEMPO ESGOTADO");
    }, 15_000);

    it("não repassa variáveis do ambiente para o script", async () => {
      process.env.SEGREDO_DO_TESTE = "vazou";
      try {
        const t = textoDe(await chamar("rodar_script", { script: "ambiente" }));
        expect(t).toContain("nada");
        expect(t).not.toContain("vazou");
      } finally {
        delete process.env.SEGREDO_DO_TESTE;
      }
    });
  });
});

describe("rodar_script em outros projetos", () => {
  it("devolve isError se o package.json não tem o script", async () => {
    const raiz = projetoTemporario({ "package.json": "{\"scripts\":{}}" });
    const cliente = await conectar(configPara(raiz));
    const r = await cliente.callTool({
      name: "rodar_script", arguments: { script: "test" } });
    expect(r.isError).toBe(true);
    expect(textoDe(r)).toContain('não tem o script "test"');
    await cliente.close();
  });

  it("some da lista quando nenhum script é liberado", async () => {
    const raiz = projetoTemporario({ "a.md": "a" });
    const cliente = await conectar(configPara(raiz, { scripts: [] }));
    const { tools } = await cliente.listTools();
    expect(tools.map((t) => t.name)).not.toContain("rodar_script");
    await cliente.close();
  });
});
