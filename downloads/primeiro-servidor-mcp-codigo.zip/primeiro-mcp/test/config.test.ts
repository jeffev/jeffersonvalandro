import { describe, expect, it } from "vitest";
import { lerConfig } from "../src/config.js";
import { projetoTemporario } from "./ajuda.js";

describe("lerConfig", () => {
  const raiz = projetoTemporario({ "a.txt": "a" });

  it("usa a pasta do argumento e o script test por padrão", () => {
    const c = lerConfig([raiz], {});
    expect(c.raiz).toBe(raiz);
    expect(c.scripts).toEqual(["test"]);
  });

  it("lê a lista de scripts do ambiente", () => {
    const c = lerConfig([raiz], { PRIMEIRO_MCP_SCRIPTS: "test, lint" });
    expect(c.scripts).toEqual(["test", "lint"]);
  });

  it("recusa nomes de script com caracteres de shell", () => {
    expect(() => lerConfig([raiz], { PRIMEIRO_MCP_SCRIPTS: "test;rm" }))
      .toThrow(/inválido/);
  });

  it("falha se a raiz não existe", () => {
    expect(() => lerConfig([raiz + "-nao-existe"], {})).toThrow();
  });
});
