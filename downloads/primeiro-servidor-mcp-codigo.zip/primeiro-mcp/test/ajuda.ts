// Utilidades dos testes: projeto temporário e cliente em memória.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { Client } from "@modelcontextprotocol/client";
import { InMemoryTransport } from "@modelcontextprotocol/server";
import type { Config } from "../src/config.js";
import { criarServidor } from "../src/servidor.js";

/** Cria um projeto de mentira numa pasta temporária. */
export function projetoTemporario(arquivos: Record<string, string>): string {
  const raiz = fs.realpathSync.native(
    fs.mkdtempSync(path.join(os.tmpdir(), "primeiro-mcp-")));
  for (const [rel, conteudo] of Object.entries(arquivos)) {
    const destino = path.join(raiz, rel);
    fs.mkdirSync(path.dirname(destino), { recursive: true });
    fs.writeFileSync(destino, conteudo);
  }
  return raiz;
}

export function configPara(raiz: string, extra: Partial<Config> = {}) {
  return { raiz, scripts: ["test"], timeoutMs: 30_000, maxSaida: 20_000,
    ...extra } satisfies Config;
}

/** Liga um Client do SDK ao servidor sem abrir processo. */
export async function conectar(config: Config) {
  const servidor = criarServidor(config);
  const [ladoCliente, ladoServidor] = InMemoryTransport.createLinkedPair();
  await servidor.connect(ladoServidor);
  const cliente = new Client({ name: "teste", version: "1.0.0" });
  await cliente.connect(ladoCliente);
  return cliente;
}

export function textoDe(resultado: any): string {
  return (resultado.content ?? []).map((c: any) => c.text ?? "").join("\n");
}
