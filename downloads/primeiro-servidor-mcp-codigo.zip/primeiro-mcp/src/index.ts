#!/usr/bin/env node
// Ponto de entrada: lê a configuração e atende pelo stdio.
// Uso: node dist/index.js [pasta-do-projeto]
import { serveStdio } from "@modelcontextprotocol/server/stdio";
import { lerConfig } from "./config.js";
import { criarServidor, NOME, VERSAO } from "./servidor.js";

// No stdio, o stdout é o canal do protocolo: todo log vai para o stderr.
const log = (msg: string) => process.stderr.write(`[${NOME}] ${msg}\n`);

try {
  const config = lerConfig();
  serveStdio(() => criarServidor(config), {
    onerror: (e) => log(`erro: ${e.message}`),
  });
  log(`v${VERSAO} pronto · raiz=${config.raiz} · ` +
    `scripts=${config.scripts.join(",") || "(nenhum)"}`);
} catch (e) {
  log(`não foi possível iniciar: ${(e as Error).message}`);
  process.exit(1);
}
