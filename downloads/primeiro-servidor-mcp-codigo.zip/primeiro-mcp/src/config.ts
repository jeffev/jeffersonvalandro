// Configuração lida da linha de comando e do ambiente.
import fs from "node:fs";
import path from "node:path";

export interface Config {
  /** Pasta do projeto (caminho real, sem symlinks). Nada sai dela. */
  raiz: string;
  /** Scripts do package.json que a tool rodar_script pode executar. */
  scripts: string[];
  /** Tempo máximo de um script, em milissegundos. */
  timeoutMs: number;
  /** Tamanho máximo do texto devolvido por uma tool. */
  maxSaida: number;
}

const NOME_DE_SCRIPT = /^[A-Za-z0-9][A-Za-z0-9:_-]*$/;

export function lerConfig(
  argv: string[] = process.argv.slice(2),
  env: NodeJS.ProcessEnv = process.env,
): Config {
  const pasta = argv[0] ?? env.PRIMEIRO_MCP_RAIZ ?? process.cwd();
  const raiz = fs.realpathSync.native(path.resolve(pasta));
  if (!fs.statSync(raiz).isDirectory()) {
    throw new Error(`A raiz não é uma pasta: ${raiz}`);
  }

  const scripts = (env.PRIMEIRO_MCP_SCRIPTS ?? "test")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  for (const s of scripts) {
    if (!NOME_DE_SCRIPT.test(s)) {
      throw new Error(`Nome de script inválido: ${JSON.stringify(s)}`);
    }
  }

  const timeoutMs = Number(env.PRIMEIRO_MCP_TIMEOUT_MS ?? 120_000);
  return { raiz, scripts, timeoutMs, maxSaida: 20_000 };
}
