// Formas de devolver resultados de tools.
import type { CallToolResult } from "@modelcontextprotocol/server";

export function texto(t: string): CallToolResult {
  return { content: [{ type: "text", text: t }] };
}

/** Erro de execução: o modelo lê a mensagem e pode tentar de novo. */
export function erro(t: string): CallToolResult {
  return { content: [{ type: "text", text: t }], isError: true };
}

/** Transforma exceções em `isError: true` em vez de derrubar a chamada. */
export async function tratarErros(
  nome: string,
  fn: () => Promise<CallToolResult> | CallToolResult,
): Promise<CallToolResult> {
  try {
    return await fn();
  } catch (e) {
    return erro(`${nome} falhou: ${(e as Error).message}`);
  }
}
