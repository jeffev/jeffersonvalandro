// O menor servidor MCP útil: uma tool, transporte stdio.
// Rode com: node dist/ola.js (ele fica esperando mensagens no stdin).
import { McpServer } from "@modelcontextprotocol/server";
import { serveStdio } from "@modelcontextprotocol/server/stdio";
import * as z from "zod/v4";

function criarServidor(): McpServer {
  const server = new McpServer({ name: "ola-mcp", version: "1.0.0" });

  server.registerTool(
    "saudar",
    {
      description: "Cumprimenta uma pessoa pelo nome.",
      inputSchema: z.object({
        nome: z.string().min(1).describe("Nome de quem vai ser saudado"),
      }),
    },
    async ({ nome }) => ({
      content: [{ type: "text", text: `Olá, ${nome}! Sou um servidor MCP.` }],
    }),
  );

  return server;
}

serveStdio(() => criarServidor());
console.error("ola-mcp pronto no stdio"); // stdout é do protocolo
