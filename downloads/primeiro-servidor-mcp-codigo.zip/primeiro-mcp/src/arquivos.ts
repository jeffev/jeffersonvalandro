// Percorre os arquivos de texto de uma pasta, respeitando as regras
// de segurança. Usado por buscar_texto e listar_todos.
import fs from "node:fs";
import path from "node:path";
import { PASTAS_IGNORADAS, ehSegredo } from "./seguranca.js";

export interface ArquivoDeTexto {
  /** Caminho relativo à raiz, sempre com "/". */
  relativo: string;
  linhas: string[];
}

const MAX_ARQUIVOS = 5_000;
const MAX_BYTES = 1_000_000; // arquivos maiores são pulados

export function* arquivosDeTexto(
  raiz: string,
  inicio: string,
): Generator<ArquivoDeTexto> {
  const pilha = [inicio];
  let vistos = 0;
  while (pilha.length > 0 && vistos < MAX_ARQUIVOS) {
    const pasta = pilha.pop()!;
    const itens = fs.readdirSync(pasta, { withFileTypes: true });
    itens.sort((a, b) => a.name.localeCompare(b.name));
    const subpastas: string[] = [];
    for (const item of itens) {
      const completo = path.join(pasta, item.name);
      if (item.isDirectory()) {
        if (!PASTAS_IGNORADAS.has(item.name)) subpastas.push(completo);
        continue;
      }
      // symlinks não são seguidos: poderiam apontar para fora da raiz
      if (!item.isFile() || ehSegredo(item.name)) continue;
      if (fs.statSync(completo).size > MAX_BYTES) continue;
      const conteudo = fs.readFileSync(completo);
      if (conteudo.subarray(0, 8000).includes(0)) continue; // binário
      vistos++;
      yield {
        relativo: path.relative(raiz, completo).split(path.sep).join("/"),
        linhas: conteudo.toString("utf8").split(/\r?\n/),
      };
    }
    pilha.push(...subpastas.reverse()); // ordem alfabética, sempre igual
  }
}
