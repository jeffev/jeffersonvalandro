// Tool listar_todos: junta os TODO/FIXME do projeto numa lista.
// Devolve texto (para o modelo ler) e dados estruturados (outputSchema).
import type { McpServer } from "@modelcontextprotocol/server";
import * as z from "zod/v4";
import { arquivosDeTexto } from "../arquivos.js";
import type { Config } from "../config.js";
import { tratarErros } from "../resultado.js";
import { limitar, resolverNaRaiz } from "../seguranca.js";

const MARCADORES = ["TODO", "FIXME", "HACK", "XXX"] as const;
const MAX_ITENS = 200;

const entrada = z.object({
  pasta: z.string().max(300).default(".")
    .describe("Subpasta, relativa à raiz do projeto"),
  marcadores: z.array(z.enum(MARCADORES)).min(1).default(["TODO", "FIXME"])
    .describe("Quais marcadores procurar"),
});

const item = z.object({
  arquivo: z.string(),
  linha: z.number(),
  marcador: z.enum(MARCADORES),
  texto: z.string(),
});
const saida = z.object({ total: z.number(), itens: z.array(item) });

export function registrarListarTodos(server: McpServer, config: Config) {
  server.registerTool(
    "listar_todos",
    {
      title: "Listar TODOs do projeto",
      description:
        "Lista comentários TODO/FIXME (e, se pedido, HACK/XXX) com " +
        "arquivo e linha. Bom para planejar o que falta fazer.",
      inputSchema: entrada,
      outputSchema: saida,
      annotations: { readOnlyHint: true, openWorldHint: false },
    },
    async ({ pasta, marcadores }) =>
      tratarErros("listar_todos", () => {
        const inicio = resolverNaRaiz(config.raiz, pasta);
        // \\b é fronteira de palavra: não casa "TODOS" nem "autodoc"
        const re = new RegExp(`\\b(${marcadores.join("|")})\\b`);
        const itens: z.infer<typeof item>[] = [];
        busca: for (const arq of arquivosDeTexto(config.raiz, inicio)) {
          for (const [i, linha] of arq.linhas.entries()) {
            const m = re.exec(linha);
            if (!m) continue;
            itens.push({
              arquivo: arq.relativo,
              linha: i + 1,
              marcador: m[1] as (typeof MARCADORES)[number],
              texto: linha.slice(m.index).trim().slice(0, 200),
            });
            if (itens.length >= MAX_ITENS) break busca;
          }
        }
        const linhas = itens.map(
          (t) => `${t.arquivo}:${t.linha}: ${t.texto}`);
        const resumo = itens.length === 0
          ? "Nenhum marcador encontrado."
          : `${itens.length} marcador(es):\n${linhas.join("\n")}`;
        const resultado = { total: itens.length, itens };
        return {
          content: [{ type: "text", text: limitar(resumo, config.maxSaida) }],
          structuredContent: resultado,
        };
      }),
  );
}
