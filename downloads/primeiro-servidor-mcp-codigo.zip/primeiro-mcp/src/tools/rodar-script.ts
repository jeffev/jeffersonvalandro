// Tool rodar_script: roda SÓ os scripts do package.json que você liberou.
// O modelo escolhe um nome da lista; o comando em si foi escrito por você.
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import type { McpServer } from "@modelcontextprotocol/server";
import * as z from "zod/v4";
import type { Config } from "../config.js";
import { erro, texto, tratarErros } from "../resultado.js";
import { ambienteDoFilho, limitar } from "../seguranca.js";

export interface Execucao {
  codigo: number | null;
  saida: string;
  estourouTempo: boolean;
}

/**
 * Executa `node --run <script>` SEM shell: o nome do script vai como
 * argumento, então caracteres como ; | & % não têm efeito especial.
 */
export function executarScript(
  config: Config,
  script: string,
): Promise<Execucao> {
  return new Promise((resolve) => {
    const filho = spawn(process.execPath, ["--run", script], {
      cwd: config.raiz,
      env: ambienteDoFilho(),
      shell: false,
      windowsHide: true,
      // Linux/macOS: grupo de processos próprio, para matar a árvore toda
      detached: process.platform !== "win32",
      stdio: ["ignore", "pipe", "pipe"],
    });
    let saida = "";
    let estourouTempo = false;
    const juntar = (parte: Buffer) => {
      if (saida.length < 2_000_000) saida += parte.toString("utf8");
    };
    filho.stdout.on("data", juntar);
    filho.stderr.on("data", juntar);
    const timer = setTimeout(() => {
      estourouTempo = true;
      encerrarArvore(filho.pid);
    }, config.timeoutMs);
    filho.on("error", (e) => { saida += `\n${e.message}`; });
    filho.on("close", (codigo) => {
      clearTimeout(timer);
      resolve({ codigo, saida, estourouTempo });
    });
  });
}

/** Matar só o processo pai deixaria os filhos dele (o script) vivos. */
function encerrarArvore(pid: number | undefined) {
  if (!pid) return;
  try {
    if (process.platform === "win32") {
      spawn("taskkill", ["/pid", String(pid), "/T", "/F"], {
        windowsHide: true,
        stdio: "ignore",
      });
    } else {
      process.kill(-pid, "SIGKILL"); // o "-" mira o grupo inteiro
    }
  } catch {
    // o processo já tinha terminado
  }
}

function scriptsDoPackageJson(raiz: string): Record<string, string> {
  const arquivo = path.join(raiz, "package.json");
  if (!fs.existsSync(arquivo)) return {};
  const pkg = JSON.parse(fs.readFileSync(arquivo, "utf8"));
  return pkg.scripts ?? {};
}

export function registrarRodarScript(server: McpServer, config: Config) {
  if (config.scripts.length === 0) return; // nada liberado, nada de tool
  const nomes = config.scripts as [string, ...string[]];

  server.registerTool(
    "rodar_script",
    {
      title: "Rodar um script permitido",
      description:
        "Roda um script do package.json do projeto (node --run) e " +
        `devolve o código de saída e o fim da saída. Permitidos: ` +
        `${nomes.join(", ")}. Use para conferir testes, lint e build.`,
      inputSchema: z.object({
        script: z.enum(nomes).describe("Nome do script na lista permitida"),
      }),
      // um script pode gravar arquivos: o cliente deve pedir confirmação
      annotations: { readOnlyHint: false, destructiveHint: true,
        openWorldHint: false },
    },
    async ({ script }) =>
      tratarErros("rodar_script", async () => {
        if (!Object.hasOwn(scriptsDoPackageJson(config.raiz), script)) {
          return erro(`O package.json não tem o script "${script}".`);
        }
        const r = await executarScript(config, script);
        const status = r.estourouTempo
          ? `TEMPO ESGOTADO após ${config.timeoutMs} ms`
          : `código de saída ${r.codigo}`;
        // o fim da saída costuma trazer o resumo dos testes
        const fim = r.saida.trim().slice(-config.maxSaida);
        return texto(limitar(`$ node --run ${script}\n${status}\n\n${fim}`,
          config.maxSaida + 200));
      }),
  );
}
