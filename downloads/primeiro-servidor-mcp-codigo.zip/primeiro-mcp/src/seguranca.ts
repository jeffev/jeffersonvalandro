// As regras de segurança ficam juntas, num arquivo pequeno e testado.
import fs from "node:fs";
import path from "node:path";

export class ErroDeSeguranca extends Error {}

const WINDOWS = process.platform === "win32";

/** true se `filho` é a própria `raiz` ou está dentro dela. */
export function estaDentro(raiz: string, filho: string): boolean {
  const a = WINDOWS ? raiz.toLowerCase() : raiz;
  const b = WINDOWS ? filho.toLowerCase() : filho;
  const rel = path.relative(a, b);
  return rel === "" || (!rel.startsWith("..") && !path.isAbsolute(rel));
}

/**
 * Converte o caminho pedido pelo modelo num caminho absoluto e garante
 * que ele (e o destino real, se for um symlink) fica dentro da raiz.
 */
export function resolverNaRaiz(raiz: string, pedido: string): string {
  if (pedido.includes("\0")) throw new ErroDeSeguranca("Caminho inválido.");
  const absoluto = path.resolve(raiz, pedido);
  if (!estaDentro(raiz, absoluto)) {
    throw new ErroDeSeguranca(`Caminho fora da raiz do projeto: ${pedido}`);
  }
  const real = fs.realpathSync.native(absoluto); // falha se não existir
  if (!estaDentro(raiz, real)) {
    throw new ErroDeSeguranca(`Caminho aponta para fora da raiz: ${pedido}`);
  }
  return real;
}

/** Pastas que nunca são percorridas. */
export const PASTAS_IGNORADAS = new Set([
  ".git", "node_modules", "dist", "build", "coverage", ".venv",
]);

/** Arquivos que podem guardar segredos: nunca são lidos. */
const SEGREDOS = [
  /^\.env(\..*)?$/i, /\.(pem|key|p12|pfx)$/i, /^id_(rsa|ed25519|ecdsa)/i,
  /^\.npmrc$/i, /^\.netrc$/i, /^credentials\.json$/i,
];
const EXCECOES = [/^\.env\.example$/i];

export function ehSegredo(nomeDoArquivo: string): boolean {
  if (EXCECOES.some((re) => re.test(nomeDoArquivo))) return false;
  return SEGREDOS.some((re) => re.test(nomeDoArquivo));
}

/** Corta textos longos e avisa quanto ficou de fora. */
export function limitar(texto: string, max: number): string {
  if (texto.length <= max) return texto;
  const resto = texto.length - max;
  return `${texto.slice(0, max)}\n[... ${resto} caracteres omitidos]`;
}

/**
 * Ambiente mínimo para processos filhos: só o necessário para achar
 * programas e pastas temporárias. Tokens e senhas do seu terminal
 * (GITHUB_TOKEN, AWS_*, ...) não passam.
 */
const VARIAVEIS_PERMITIDAS = new Set([
  "PATH", "PATHEXT", "SYSTEMROOT", "COMSPEC", "TEMP", "TMP", "TMPDIR",
  "HOME", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "LANG", "TERM",
  "CI", "NODE_ENV",
]);

export function ambienteDoFilho(
  env: NodeJS.ProcessEnv = process.env,
): NodeJS.ProcessEnv {
  const limpo: NodeJS.ProcessEnv = {};
  for (const [nome, valor] of Object.entries(env)) {
    // no Windows "Path" e "PATH" são a mesma variável
    if (VARIAVEIS_PERMITIDAS.has(nome.toUpperCase())) limpo[nome] = valor;
  }
  return limpo;
}
