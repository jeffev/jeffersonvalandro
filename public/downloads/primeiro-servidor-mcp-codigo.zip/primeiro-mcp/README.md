# primeiro-mcp

Código do livro gratuito **Seu Primeiro Servidor MCP: conecte a IA às suas ferramentas**, de Jefferson Valandro
(ValandroUI). É um servidor MCP pequeno, em TypeScript, que dá a um agente de IA (Claude Code, Cursor, VS Code...)
três ferramentas sobre **uma pasta de projeto**:

| Tool | O que faz | Muda algo? |
|---|---|---|
| `buscar_texto` | procura um texto literal nos arquivos de texto e devolve `arquivo:linha: trecho` | não |
| `listar_todos` | lista comentários TODO/FIXME (e HACK/XXX, se pedido), em texto e em dados estruturados | não |
| `rodar_script` | roda **só** os scripts do `package.json` que você liberou (padrão: `test`) | pode |

Regras de segurança já embutidas: nada sai da pasta raiz (nem por `..`, nem por symlink/junction), arquivos de
segredo (`.env`, `*.pem`, `id_rsa`...) não são lidos, `node_modules`/`.git`/`dist` são ignorados, scripts rodam sem
shell e com um ambiente mínimo (seus tokens não passam para eles), e toda saída tem limite de tamanho.

## Requisitos

- Node.js **22 ou mais novo** (o `rodar_script` usa `node --run`; o MCP Inspector 2.x pede 22.19+).
- npm (vem com o Node).

## Instalar, compilar e testar

```bash
npm ci
npm run build
npm test
```

`npm test` compila de novo e roda os testes com Vitest: regras de segurança, configuração, cada tool por um cliente
em memória e o servidor de verdade pelo stdio (nas duas eras do protocolo: 2025-11-25 e 2026-07-28).

## Experimentar sem IA nenhuma

```bash
npm run build
node scripts/cliente.mjs exemplo
```

O script sobe o servidor apontando para a pasta `exemplo/` (uma lojinha de mentira), lista as tools e chama cada uma,
inclusive chamadas que **devem** falhar (pasta fora da raiz, script não liberado).

Com o MCP Inspector (interface web; baixa o pacote na primeira vez):

```bash
npx @modelcontextprotocol/inspector node dist/index.js exemplo
```

Ou em modo linha de comando:

```bash
npx @modelcontextprotocol/inspector --cli node dist/index.js exemplo --method tools/list
```

## Ligar no Claude Code

Dentro da pasta do **seu** projeto (troque o caminho pelo lugar onde você extraiu este código):

```bash
claude mcp add primeiro-mcp --scope project -e PRIMEIRO_MCP_SCRIPTS=test,lint -- node /caminho/para/primeiro-mcp/dist/index.js .
```

Atenção à ordem: o nome (`primeiro-mcp`) vem **antes** do `-e`. A opção `-e` aceita vários valores e, se vier antes,
engole o nome do servidor.

Isso cria um `.mcp.json` na raiz do projeto. Também dá para escrever o arquivo à mão:

```json
{
  "mcpServers": {
    "primeiro-mcp": {
      "type": "stdio",
      "command": "node",
      "args": ["/caminho/para/primeiro-mcp/dist/index.js", "."],
      "env": { "PRIMEIRO_MCP_SCRIPTS": "test,lint" }
    }
  }
}
```

Na primeira sessão interativa (`claude`), o Claude Code pede aprovação para servidores de projeto. Depois, `/mcp`
mostra o status.

## Configuração

| Onde | O quê | Padrão |
|---|---|---|
| 1º argumento | pasta raiz do projeto | `PRIMEIRO_MCP_RAIZ` ou a pasta atual |
| `PRIMEIRO_MCP_SCRIPTS` | scripts liberados, separados por vírgula | `test` |
| `PRIMEIRO_MCP_TIMEOUT_MS` | tempo máximo de um script | `120000` |

## Estrutura

```
src/
  index.ts           entrada: lê a config e atende pelo stdio
  servidor.ts        cria o McpServer e registra as tools
  config.ts          argumentos e variáveis de ambiente
  seguranca.ts       raiz, segredos, limites, ambiente dos filhos
  arquivos.ts        percorre arquivos de texto com segurança
  resultado.ts       texto, erro (isError) e tratamento de exceções
  ola.ts             o servidor mínimo do capítulo 3 (tool saudar)
  tools/
    buscar-texto.ts
    listar-todos.ts
    rodar-script.ts
test/                Vitest (unidade, cliente em memória e stdio)
scripts/cliente.mjs  cliente MCP de linha de comando
exemplo/             projeto de mentira para experimentar
```

## Versões usadas (outubro de 2026)

`@modelcontextprotocol/server` 2.3.1 e `@modelcontextprotocol/client` 2.3.1 (SDK oficial v2), `zod` 4.6.5,
TypeScript 7.0.2, Vitest 5.0.3, testado com Node.js 24.13.0 no Windows 11 e Claude Code 2.1.296.

## Licença

Código sob a licença MIT (arquivo `LICENSE`). O livro é gratuito e pode ser compartilhado sem alterações; ele não
pode ser vendido.

Quer ir além (20 tools, specs, agents, skills, hooks)? Veja o livro *IA no Fluxo do Dev*, na Amazon (links atualizados em
https://jeffev.github.io/jeffersonvalandro/#products).
